﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmShipColor
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmShipColor))
        Me.txtOutput = New System.Windows.Forms.TextBox()
        Me.ColorDialog1 = New System.Windows.Forms.ColorDialog()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.blkPrime = New System.Windows.Forms.PictureBox()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.cmdLoadColorMap = New System.Windows.Forms.Button()
        Me.cmdSaveColorMap = New System.Windows.Forms.Button()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.cmdOutfitJSON = New System.Windows.Forms.Button()
        Me.cmdMonoGen = New System.Windows.Forms.Button()
        Me.txtMonoA = New System.Windows.Forms.TextBox()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.txtMonoB = New System.Windows.Forms.TextBox()
        Me.Label41 = New System.Windows.Forms.Label()
        Me.txtMonoG = New System.Windows.Forms.TextBox()
        Me.Label43 = New System.Windows.Forms.Label()
        Me.txtMonoR = New System.Windows.Forms.TextBox()
        Me.Label45 = New System.Windows.Forms.Label()
        Me.cmdGenerate = New System.Windows.Forms.Button()
        Me.gbColorMap = New System.Windows.Forms.GroupBox()
        Me.cbCust05 = New System.Windows.Forms.ComboBox()
        Me.cbCust04 = New System.Windows.Forms.ComboBox()
        Me.lblC5Alt4 = New System.Windows.Forms.Label()
        Me.lblC5Alt3 = New System.Windows.Forms.Label()
        Me.lblC5Alt2 = New System.Windows.Forms.Label()
        Me.lblC5Alt1 = New System.Windows.Forms.Label()
        Me.lblC5Primary = New System.Windows.Forms.Label()
        Me.lblC4Alt4 = New System.Windows.Forms.Label()
        Me.lblC4Alt3 = New System.Windows.Forms.Label()
        Me.lblC4Alt2 = New System.Windows.Forms.Label()
        Me.lblC4Alt1 = New System.Windows.Forms.Label()
        Me.lblC4Primary = New System.Windows.Forms.Label()
        Me.lblC3Alt4 = New System.Windows.Forms.Label()
        Me.lblC3Alt3 = New System.Windows.Forms.Label()
        Me.lblC3Alt2 = New System.Windows.Forms.Label()
        Me.lblC3Alt1 = New System.Windows.Forms.Label()
        Me.lblC3Primary = New System.Windows.Forms.Label()
        Me.lblC2Alt4 = New System.Windows.Forms.Label()
        Me.lblC2Alt3 = New System.Windows.Forms.Label()
        Me.lblC2Alt2 = New System.Windows.Forms.Label()
        Me.lblC2Alt1 = New System.Windows.Forms.Label()
        Me.lblC2Primary = New System.Windows.Forms.Label()
        Me.cbCust03 = New System.Windows.Forms.ComboBox()
        Me.cbCust02 = New System.Windows.Forms.ComboBox()
        Me.cbCust01 = New System.Windows.Forms.ComboBox()
        Me.lblC1Alt4 = New System.Windows.Forms.Label()
        Me.lblC1Alt3 = New System.Windows.Forms.Label()
        Me.lblC1Alt2 = New System.Windows.Forms.Label()
        Me.lblC1Alt1 = New System.Windows.Forms.Label()
        Me.lblC1Primary = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label50 = New System.Windows.Forms.Label()
        Me.Label48 = New System.Windows.Forms.Label()
        Me.Label47 = New System.Windows.Forms.Label()
        Me.Label46 = New System.Windows.Forms.Label()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.Label42 = New System.Windows.Forms.Label()
        Me.Label44 = New System.Windows.Forms.Label()
        Me.Label49 = New System.Windows.Forms.Label()
        Me.lblSolarSails = New System.Windows.Forms.Label()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.lblRockAlt4 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.lblRockAlt3 = New System.Windows.Forms.Label()
        Me.lblStoneAlt4 = New System.Windows.Forms.Label()
        Me.lblRockAlt2 = New System.Windows.Forms.Label()
        Me.lblStoneAlt3 = New System.Windows.Forms.Label()
        Me.lblRockAlt1 = New System.Windows.Forms.Label()
        Me.lblStoneAlt2 = New System.Windows.Forms.Label()
        Me.lblRockPrimary = New System.Windows.Forms.Label()
        Me.lblStoneAlt1 = New System.Windows.Forms.Label()
        Me.lblStonePrimary = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.lblMetalAlt4 = New System.Windows.Forms.Label()
        Me.lblMetalAlt3 = New System.Windows.Forms.Label()
        Me.lblMetalAlt2 = New System.Windows.Forms.Label()
        Me.lblMetalAlt1 = New System.Windows.Forms.Label()
        Me.lblMetalPrimary = New System.Windows.Forms.Label()
        Me.lblPaintAlt4 = New System.Windows.Forms.Label()
        Me.lblPaintAlt3 = New System.Windows.Forms.Label()
        Me.lblPaintAlt2 = New System.Windows.Forms.Label()
        Me.lblPaintAlt1 = New System.Windows.Forms.Label()
        Me.lblUndercoatAlt4 = New System.Windows.Forms.Label()
        Me.lblUndercoatAlt3 = New System.Windows.Forms.Label()
        Me.lblUndercoatAlt2 = New System.Windows.Forms.Label()
        Me.lblUndercoatAlt1 = New System.Windows.Forms.Label()
        Me.lblUndercoatPrimary = New System.Windows.Forms.Label()
        Me.lblPaintPrimary = New System.Windows.Forms.Label()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.cmdPaintAlternative1 = New System.Windows.Forms.Button()
        Me.cmdPaintAlternative2 = New System.Windows.Forms.Button()
        Me.cmdUndercoatPrimary = New System.Windows.Forms.Button()
        Me.cmdPaintAlt3 = New System.Windows.Forms.Button()
        Me.cmdPaintPrimary = New System.Windows.Forms.Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.pbActive = New System.Windows.Forms.PictureBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtActiveARGB = New System.Windows.Forms.TextBox()
        Me.cmdASelect = New System.Windows.Forms.Button()
        Me.cmdAPrev = New System.Windows.Forms.Button()
        Me.txtAA = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtAB = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtAG = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtAR = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip()
        Me.frmStatus = New System.Windows.Forms.ToolStripStatusLabel()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.SaveFileDialog1 = New System.Windows.Forms.SaveFileDialog()
        CType(Me.blkPrime, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.gbColorMap.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        CType(Me.pbActive, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.StatusStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'txtOutput
        '
        Me.txtOutput.Location = New System.Drawing.Point(715, 12)
        Me.txtOutput.Multiline = True
        Me.txtOutput.Name = "txtOutput"
        Me.txtOutput.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.txtOutput.Size = New System.Drawing.Size(455, 581)
        Me.txtOutput.TabIndex = 0
        '
        'blkPrime
        '
        Me.blkPrime.Image = CType(resources.GetObject("blkPrime.Image"), System.Drawing.Image)
        Me.blkPrime.Location = New System.Drawing.Point(116, 138)
        Me.blkPrime.Name = "blkPrime"
        Me.blkPrime.Size = New System.Drawing.Size(37, 30)
        Me.blkPrime.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.blkPrime.TabIndex = 11
        Me.blkPrime.TabStop = False
        Me.ToolTip1.SetToolTip(Me.blkPrime, "Pitch Black")
        '
        'Label35
        '
        Me.Label35.Font = New System.Drawing.Font("Consolas", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label35.Location = New System.Drawing.Point(578, 172)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(104, 21)
        Me.Label35.TabIndex = 79
        Me.Label35.Text = "Fill"
        Me.Label35.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ToolTip1.SetToolTip(Me.Label35, "Misc. Fill colors will be used as default colors for all non-selected palettes.")
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.cmdLoadColorMap)
        Me.GroupBox2.Controls.Add(Me.cmdSaveColorMap)
        Me.GroupBox2.Controls.Add(Me.GroupBox5)
        Me.GroupBox2.Controls.Add(Me.cmdGenerate)
        Me.GroupBox2.Controls.Add(Me.gbColorMap)
        Me.GroupBox2.Controls.Add(Me.GroupBox3)
        Me.GroupBox2.Controls.Add(Me.GroupBox1)
        Me.GroupBox2.Location = New System.Drawing.Point(3, 5)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(706, 588)
        Me.GroupBox2.TabIndex = 3
        Me.GroupBox2.TabStop = False
        '
        'cmdLoadColorMap
        '
        Me.cmdLoadColorMap.Location = New System.Drawing.Point(122, 558)
        Me.cmdLoadColorMap.Name = "cmdLoadColorMap"
        Me.cmdLoadColorMap.Size = New System.Drawing.Size(114, 23)
        Me.cmdLoadColorMap.TabIndex = 23
        Me.cmdLoadColorMap.Text = "Load Color Map"
        Me.cmdLoadColorMap.UseVisualStyleBackColor = True
        '
        'cmdSaveColorMap
        '
        Me.cmdSaveColorMap.Location = New System.Drawing.Point(6, 558)
        Me.cmdSaveColorMap.Name = "cmdSaveColorMap"
        Me.cmdSaveColorMap.Size = New System.Drawing.Size(114, 23)
        Me.cmdSaveColorMap.TabIndex = 22
        Me.cmdSaveColorMap.Text = "Save Color Map"
        Me.cmdSaveColorMap.UseVisualStyleBackColor = True
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.cmdOutfitJSON)
        Me.GroupBox5.Controls.Add(Me.cmdMonoGen)
        Me.GroupBox5.Controls.Add(Me.txtMonoA)
        Me.GroupBox5.Controls.Add(Me.Label39)
        Me.GroupBox5.Controls.Add(Me.txtMonoB)
        Me.GroupBox5.Controls.Add(Me.Label41)
        Me.GroupBox5.Controls.Add(Me.txtMonoG)
        Me.GroupBox5.Controls.Add(Me.Label43)
        Me.GroupBox5.Controls.Add(Me.txtMonoR)
        Me.GroupBox5.Controls.Add(Me.Label45)
        Me.GroupBox5.Location = New System.Drawing.Point(539, 19)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(160, 198)
        Me.GroupBox5.TabIndex = 20
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Mono Color Generator"
        '
        'cmdOutfitJSON
        '
        Me.cmdOutfitJSON.Location = New System.Drawing.Point(6, 136)
        Me.cmdOutfitJSON.Name = "cmdOutfitJSON"
        Me.cmdOutfitJSON.Size = New System.Drawing.Size(147, 23)
        Me.cmdOutfitJSON.TabIndex = 10
        Me.cmdOutfitJSON.Text = "Generate Outfit JSON"
        Me.cmdOutfitJSON.UseVisualStyleBackColor = True
        '
        'cmdMonoGen
        '
        Me.cmdMonoGen.Location = New System.Drawing.Point(6, 112)
        Me.cmdMonoGen.Name = "cmdMonoGen"
        Me.cmdMonoGen.Size = New System.Drawing.Size(147, 23)
        Me.cmdMonoGen.TabIndex = 9
        Me.cmdMonoGen.Text = "Generate Ship JSON"
        Me.cmdMonoGen.UseVisualStyleBackColor = True
        '
        'txtMonoA
        '
        Me.txtMonoA.Location = New System.Drawing.Point(26, 86)
        Me.txtMonoA.Name = "txtMonoA"
        Me.txtMonoA.Size = New System.Drawing.Size(127, 20)
        Me.txtMonoA.TabIndex = 7
        Me.txtMonoA.Text = "1.0"
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.Location = New System.Drawing.Point(7, 89)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(13, 13)
        Me.Label39.TabIndex = 6
        Me.Label39.Text = "A"
        '
        'txtMonoB
        '
        Me.txtMonoB.Location = New System.Drawing.Point(26, 64)
        Me.txtMonoB.Name = "txtMonoB"
        Me.txtMonoB.Size = New System.Drawing.Size(127, 20)
        Me.txtMonoB.TabIndex = 5
        Me.txtMonoB.Text = "0.1"
        '
        'Label41
        '
        Me.Label41.AutoSize = True
        Me.Label41.Location = New System.Drawing.Point(7, 67)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(13, 13)
        Me.Label41.TabIndex = 4
        Me.Label41.Text = "B"
        '
        'txtMonoG
        '
        Me.txtMonoG.Location = New System.Drawing.Point(26, 42)
        Me.txtMonoG.Name = "txtMonoG"
        Me.txtMonoG.Size = New System.Drawing.Size(127, 20)
        Me.txtMonoG.TabIndex = 3
        Me.txtMonoG.Text = "0.1"
        '
        'Label43
        '
        Me.Label43.AutoSize = True
        Me.Label43.Location = New System.Drawing.Point(7, 45)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(13, 13)
        Me.Label43.TabIndex = 2
        Me.Label43.Text = "G"
        '
        'txtMonoR
        '
        Me.txtMonoR.Location = New System.Drawing.Point(26, 20)
        Me.txtMonoR.Name = "txtMonoR"
        Me.txtMonoR.Size = New System.Drawing.Size(127, 20)
        Me.txtMonoR.TabIndex = 1
        Me.txtMonoR.Text = "0.1"
        '
        'Label45
        '
        Me.Label45.AutoSize = True
        Me.Label45.Location = New System.Drawing.Point(7, 23)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(13, 13)
        Me.Label45.TabIndex = 0
        Me.Label45.Text = "R"
        '
        'cmdGenerate
        '
        Me.cmdGenerate.Location = New System.Drawing.Point(513, 558)
        Me.cmdGenerate.Name = "cmdGenerate"
        Me.cmdGenerate.Size = New System.Drawing.Size(186, 23)
        Me.cmdGenerate.TabIndex = 18
        Me.cmdGenerate.Text = "Generate Colours JSON"
        Me.cmdGenerate.UseVisualStyleBackColor = True
        '
        'gbColorMap
        '
        Me.gbColorMap.Controls.Add(Me.cbCust05)
        Me.gbColorMap.Controls.Add(Me.cbCust04)
        Me.gbColorMap.Controls.Add(Me.lblC5Alt4)
        Me.gbColorMap.Controls.Add(Me.lblC5Alt3)
        Me.gbColorMap.Controls.Add(Me.lblC5Alt2)
        Me.gbColorMap.Controls.Add(Me.lblC5Alt1)
        Me.gbColorMap.Controls.Add(Me.lblC5Primary)
        Me.gbColorMap.Controls.Add(Me.lblC4Alt4)
        Me.gbColorMap.Controls.Add(Me.lblC4Alt3)
        Me.gbColorMap.Controls.Add(Me.lblC4Alt2)
        Me.gbColorMap.Controls.Add(Me.lblC4Alt1)
        Me.gbColorMap.Controls.Add(Me.lblC4Primary)
        Me.gbColorMap.Controls.Add(Me.lblC3Alt4)
        Me.gbColorMap.Controls.Add(Me.lblC3Alt3)
        Me.gbColorMap.Controls.Add(Me.lblC3Alt2)
        Me.gbColorMap.Controls.Add(Me.lblC3Alt1)
        Me.gbColorMap.Controls.Add(Me.lblC3Primary)
        Me.gbColorMap.Controls.Add(Me.lblC2Alt4)
        Me.gbColorMap.Controls.Add(Me.lblC2Alt3)
        Me.gbColorMap.Controls.Add(Me.lblC2Alt2)
        Me.gbColorMap.Controls.Add(Me.lblC2Alt1)
        Me.gbColorMap.Controls.Add(Me.lblC2Primary)
        Me.gbColorMap.Controls.Add(Me.cbCust03)
        Me.gbColorMap.Controls.Add(Me.cbCust02)
        Me.gbColorMap.Controls.Add(Me.cbCust01)
        Me.gbColorMap.Controls.Add(Me.lblC1Alt4)
        Me.gbColorMap.Controls.Add(Me.lblC1Alt3)
        Me.gbColorMap.Controls.Add(Me.lblC1Alt2)
        Me.gbColorMap.Controls.Add(Me.lblC1Alt1)
        Me.gbColorMap.Controls.Add(Me.lblC1Primary)
        Me.gbColorMap.Controls.Add(Me.Label6)
        Me.gbColorMap.Controls.Add(Me.Label7)
        Me.gbColorMap.Controls.Add(Me.Label8)
        Me.gbColorMap.Controls.Add(Me.Label9)
        Me.gbColorMap.Controls.Add(Me.Label10)
        Me.gbColorMap.Controls.Add(Me.Label50)
        Me.gbColorMap.Controls.Add(Me.Label48)
        Me.gbColorMap.Controls.Add(Me.Label47)
        Me.gbColorMap.Controls.Add(Me.Label46)
        Me.gbColorMap.Controls.Add(Me.Label37)
        Me.gbColorMap.Controls.Add(Me.Label35)
        Me.gbColorMap.Controls.Add(Me.Label36)
        Me.gbColorMap.Controls.Add(Me.Label38)
        Me.gbColorMap.Controls.Add(Me.Label40)
        Me.gbColorMap.Controls.Add(Me.Label42)
        Me.gbColorMap.Controls.Add(Me.Label44)
        Me.gbColorMap.Controls.Add(Me.Label49)
        Me.gbColorMap.Controls.Add(Me.lblSolarSails)
        Me.gbColorMap.Controls.Add(Me.Label29)
        Me.gbColorMap.Controls.Add(Me.lblRockAlt4)
        Me.gbColorMap.Controls.Add(Me.Label23)
        Me.gbColorMap.Controls.Add(Me.lblRockAlt3)
        Me.gbColorMap.Controls.Add(Me.lblStoneAlt4)
        Me.gbColorMap.Controls.Add(Me.lblRockAlt2)
        Me.gbColorMap.Controls.Add(Me.lblStoneAlt3)
        Me.gbColorMap.Controls.Add(Me.lblRockAlt1)
        Me.gbColorMap.Controls.Add(Me.lblStoneAlt2)
        Me.gbColorMap.Controls.Add(Me.lblRockPrimary)
        Me.gbColorMap.Controls.Add(Me.lblStoneAlt1)
        Me.gbColorMap.Controls.Add(Me.lblStonePrimary)
        Me.gbColorMap.Controls.Add(Me.Label22)
        Me.gbColorMap.Controls.Add(Me.Label21)
        Me.gbColorMap.Controls.Add(Me.Label20)
        Me.gbColorMap.Controls.Add(Me.lblMetalAlt4)
        Me.gbColorMap.Controls.Add(Me.lblMetalAlt3)
        Me.gbColorMap.Controls.Add(Me.lblMetalAlt2)
        Me.gbColorMap.Controls.Add(Me.lblMetalAlt1)
        Me.gbColorMap.Controls.Add(Me.lblMetalPrimary)
        Me.gbColorMap.Controls.Add(Me.lblPaintAlt4)
        Me.gbColorMap.Controls.Add(Me.lblPaintAlt3)
        Me.gbColorMap.Controls.Add(Me.lblPaintAlt2)
        Me.gbColorMap.Controls.Add(Me.lblPaintAlt1)
        Me.gbColorMap.Controls.Add(Me.lblUndercoatAlt4)
        Me.gbColorMap.Controls.Add(Me.lblUndercoatAlt3)
        Me.gbColorMap.Controls.Add(Me.lblUndercoatAlt2)
        Me.gbColorMap.Controls.Add(Me.lblUndercoatAlt1)
        Me.gbColorMap.Controls.Add(Me.lblUndercoatPrimary)
        Me.gbColorMap.Controls.Add(Me.lblPaintPrimary)
        Me.gbColorMap.Location = New System.Drawing.Point(7, 223)
        Me.gbColorMap.Name = "gbColorMap"
        Me.gbColorMap.Size = New System.Drawing.Size(692, 329)
        Me.gbColorMap.TabIndex = 17
        Me.gbColorMap.TabStop = False
        Me.gbColorMap.Text = "Color Map"
        '
        'cbCust05
        '
        Me.cbCust05.FormattingEnabled = True
        Me.cbCust05.Location = New System.Drawing.Point(480, 169)
        Me.cbCust05.Name = "cbCust05"
        Me.cbCust05.Size = New System.Drawing.Size(93, 21)
        Me.cbCust05.TabIndex = 145
        '
        'cbCust04
        '
        Me.cbCust04.FormattingEnabled = True
        Me.cbCust04.Location = New System.Drawing.Point(381, 169)
        Me.cbCust04.Name = "cbCust04"
        Me.cbCust04.Size = New System.Drawing.Size(93, 21)
        Me.cbCust04.TabIndex = 144
        '
        'lblC5Alt4
        '
        Me.lblC5Alt4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblC5Alt4.Location = New System.Drawing.Point(480, 294)
        Me.lblC5Alt4.Name = "lblC5Alt4"
        Me.lblC5Alt4.Size = New System.Drawing.Size(93, 21)
        Me.lblC5Alt4.TabIndex = 143
        Me.lblC5Alt4.Tag = ""
        Me.lblC5Alt4.Text = "Alternative4"
        Me.lblC5Alt4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblC5Alt3
        '
        Me.lblC5Alt3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblC5Alt3.Location = New System.Drawing.Point(480, 268)
        Me.lblC5Alt3.Name = "lblC5Alt3"
        Me.lblC5Alt3.Size = New System.Drawing.Size(93, 21)
        Me.lblC5Alt3.TabIndex = 142
        Me.lblC5Alt3.Tag = ""
        Me.lblC5Alt3.Text = "Alternative3"
        Me.lblC5Alt3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblC5Alt2
        '
        Me.lblC5Alt2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblC5Alt2.Location = New System.Drawing.Point(480, 243)
        Me.lblC5Alt2.Name = "lblC5Alt2"
        Me.lblC5Alt2.Size = New System.Drawing.Size(93, 21)
        Me.lblC5Alt2.TabIndex = 141
        Me.lblC5Alt2.Tag = ""
        Me.lblC5Alt2.Text = "Alternative2"
        Me.lblC5Alt2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblC5Alt1
        '
        Me.lblC5Alt1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblC5Alt1.Location = New System.Drawing.Point(480, 218)
        Me.lblC5Alt1.Name = "lblC5Alt1"
        Me.lblC5Alt1.Size = New System.Drawing.Size(93, 21)
        Me.lblC5Alt1.TabIndex = 140
        Me.lblC5Alt1.Tag = ""
        Me.lblC5Alt1.Text = "Alternative1"
        Me.lblC5Alt1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblC5Primary
        '
        Me.lblC5Primary.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblC5Primary.Location = New System.Drawing.Point(480, 193)
        Me.lblC5Primary.Name = "lblC5Primary"
        Me.lblC5Primary.Size = New System.Drawing.Size(93, 21)
        Me.lblC5Primary.TabIndex = 139
        Me.lblC5Primary.Tag = ""
        Me.lblC5Primary.Text = "Primary"
        Me.lblC5Primary.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblC4Alt4
        '
        Me.lblC4Alt4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblC4Alt4.Location = New System.Drawing.Point(381, 294)
        Me.lblC4Alt4.Name = "lblC4Alt4"
        Me.lblC4Alt4.Size = New System.Drawing.Size(93, 21)
        Me.lblC4Alt4.TabIndex = 137
        Me.lblC4Alt4.Tag = ""
        Me.lblC4Alt4.Text = "Alternative4"
        Me.lblC4Alt4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblC4Alt3
        '
        Me.lblC4Alt3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblC4Alt3.Location = New System.Drawing.Point(381, 268)
        Me.lblC4Alt3.Name = "lblC4Alt3"
        Me.lblC4Alt3.Size = New System.Drawing.Size(93, 21)
        Me.lblC4Alt3.TabIndex = 136
        Me.lblC4Alt3.Tag = ""
        Me.lblC4Alt3.Text = "Alternative3"
        Me.lblC4Alt3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblC4Alt2
        '
        Me.lblC4Alt2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblC4Alt2.Location = New System.Drawing.Point(381, 243)
        Me.lblC4Alt2.Name = "lblC4Alt2"
        Me.lblC4Alt2.Size = New System.Drawing.Size(93, 21)
        Me.lblC4Alt2.TabIndex = 135
        Me.lblC4Alt2.Tag = ""
        Me.lblC4Alt2.Text = "Alternative2"
        Me.lblC4Alt2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblC4Alt1
        '
        Me.lblC4Alt1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblC4Alt1.Location = New System.Drawing.Point(381, 218)
        Me.lblC4Alt1.Name = "lblC4Alt1"
        Me.lblC4Alt1.Size = New System.Drawing.Size(93, 21)
        Me.lblC4Alt1.TabIndex = 134
        Me.lblC4Alt1.Tag = ""
        Me.lblC4Alt1.Text = "Alternative1"
        Me.lblC4Alt1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblC4Primary
        '
        Me.lblC4Primary.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblC4Primary.Location = New System.Drawing.Point(381, 193)
        Me.lblC4Primary.Name = "lblC4Primary"
        Me.lblC4Primary.Size = New System.Drawing.Size(93, 21)
        Me.lblC4Primary.TabIndex = 133
        Me.lblC4Primary.Tag = ""
        Me.lblC4Primary.Text = "Primary"
        Me.lblC4Primary.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblC3Alt4
        '
        Me.lblC3Alt4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblC3Alt4.Location = New System.Drawing.Point(280, 294)
        Me.lblC3Alt4.Name = "lblC3Alt4"
        Me.lblC3Alt4.Size = New System.Drawing.Size(93, 21)
        Me.lblC3Alt4.TabIndex = 132
        Me.lblC3Alt4.Tag = ""
        Me.lblC3Alt4.Text = "Alternative4"
        Me.lblC3Alt4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblC3Alt3
        '
        Me.lblC3Alt3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblC3Alt3.Location = New System.Drawing.Point(280, 268)
        Me.lblC3Alt3.Name = "lblC3Alt3"
        Me.lblC3Alt3.Size = New System.Drawing.Size(93, 21)
        Me.lblC3Alt3.TabIndex = 131
        Me.lblC3Alt3.Tag = ""
        Me.lblC3Alt3.Text = "Alternative3"
        Me.lblC3Alt3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblC3Alt2
        '
        Me.lblC3Alt2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblC3Alt2.Location = New System.Drawing.Point(280, 243)
        Me.lblC3Alt2.Name = "lblC3Alt2"
        Me.lblC3Alt2.Size = New System.Drawing.Size(93, 21)
        Me.lblC3Alt2.TabIndex = 130
        Me.lblC3Alt2.Tag = ""
        Me.lblC3Alt2.Text = "Alternative2"
        Me.lblC3Alt2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblC3Alt1
        '
        Me.lblC3Alt1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblC3Alt1.Location = New System.Drawing.Point(280, 218)
        Me.lblC3Alt1.Name = "lblC3Alt1"
        Me.lblC3Alt1.Size = New System.Drawing.Size(93, 21)
        Me.lblC3Alt1.TabIndex = 129
        Me.lblC3Alt1.Tag = ""
        Me.lblC3Alt1.Text = "Alternative1"
        Me.lblC3Alt1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblC3Primary
        '
        Me.lblC3Primary.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblC3Primary.Location = New System.Drawing.Point(280, 193)
        Me.lblC3Primary.Name = "lblC3Primary"
        Me.lblC3Primary.Size = New System.Drawing.Size(93, 21)
        Me.lblC3Primary.TabIndex = 128
        Me.lblC3Primary.Tag = ""
        Me.lblC3Primary.Text = "Primary"
        Me.lblC3Primary.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblC2Alt4
        '
        Me.lblC2Alt4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblC2Alt4.Location = New System.Drawing.Point(178, 294)
        Me.lblC2Alt4.Name = "lblC2Alt4"
        Me.lblC2Alt4.Size = New System.Drawing.Size(93, 21)
        Me.lblC2Alt4.TabIndex = 127
        Me.lblC2Alt4.Tag = ""
        Me.lblC2Alt4.Text = "Alternative4"
        Me.lblC2Alt4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblC2Alt3
        '
        Me.lblC2Alt3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblC2Alt3.Location = New System.Drawing.Point(178, 268)
        Me.lblC2Alt3.Name = "lblC2Alt3"
        Me.lblC2Alt3.Size = New System.Drawing.Size(93, 21)
        Me.lblC2Alt3.TabIndex = 126
        Me.lblC2Alt3.Tag = ""
        Me.lblC2Alt3.Text = "Alternative3"
        Me.lblC2Alt3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblC2Alt2
        '
        Me.lblC2Alt2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblC2Alt2.Location = New System.Drawing.Point(178, 243)
        Me.lblC2Alt2.Name = "lblC2Alt2"
        Me.lblC2Alt2.Size = New System.Drawing.Size(93, 21)
        Me.lblC2Alt2.TabIndex = 125
        Me.lblC2Alt2.Tag = ""
        Me.lblC2Alt2.Text = "Alternative2"
        Me.lblC2Alt2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblC2Alt1
        '
        Me.lblC2Alt1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblC2Alt1.Location = New System.Drawing.Point(178, 218)
        Me.lblC2Alt1.Name = "lblC2Alt1"
        Me.lblC2Alt1.Size = New System.Drawing.Size(93, 21)
        Me.lblC2Alt1.TabIndex = 124
        Me.lblC2Alt1.Tag = ""
        Me.lblC2Alt1.Text = "Alternative1"
        Me.lblC2Alt1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblC2Primary
        '
        Me.lblC2Primary.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblC2Primary.Location = New System.Drawing.Point(178, 193)
        Me.lblC2Primary.Name = "lblC2Primary"
        Me.lblC2Primary.Size = New System.Drawing.Size(93, 21)
        Me.lblC2Primary.TabIndex = 123
        Me.lblC2Primary.Tag = ""
        Me.lblC2Primary.Text = "Primary"
        Me.lblC2Primary.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'cbCust03
        '
        Me.cbCust03.FormattingEnabled = True
        Me.cbCust03.Location = New System.Drawing.Point(280, 169)
        Me.cbCust03.Name = "cbCust03"
        Me.cbCust03.Size = New System.Drawing.Size(93, 21)
        Me.cbCust03.TabIndex = 122
        '
        'cbCust02
        '
        Me.cbCust02.FormattingEnabled = True
        Me.cbCust02.Location = New System.Drawing.Point(178, 169)
        Me.cbCust02.Name = "cbCust02"
        Me.cbCust02.Size = New System.Drawing.Size(93, 21)
        Me.cbCust02.TabIndex = 121
        '
        'cbCust01
        '
        Me.cbCust01.FormattingEnabled = True
        Me.cbCust01.Location = New System.Drawing.Point(77, 169)
        Me.cbCust01.Name = "cbCust01"
        Me.cbCust01.Size = New System.Drawing.Size(93, 21)
        Me.cbCust01.TabIndex = 120
        '
        'lblC1Alt4
        '
        Me.lblC1Alt4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblC1Alt4.Location = New System.Drawing.Point(77, 294)
        Me.lblC1Alt4.Name = "lblC1Alt4"
        Me.lblC1Alt4.Size = New System.Drawing.Size(93, 21)
        Me.lblC1Alt4.TabIndex = 106
        Me.lblC1Alt4.Tag = ""
        Me.lblC1Alt4.Text = "Alternative4"
        Me.lblC1Alt4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblC1Alt3
        '
        Me.lblC1Alt3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblC1Alt3.Location = New System.Drawing.Point(77, 268)
        Me.lblC1Alt3.Name = "lblC1Alt3"
        Me.lblC1Alt3.Size = New System.Drawing.Size(93, 21)
        Me.lblC1Alt3.TabIndex = 105
        Me.lblC1Alt3.Tag = ""
        Me.lblC1Alt3.Text = "Alternative3"
        Me.lblC1Alt3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblC1Alt2
        '
        Me.lblC1Alt2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblC1Alt2.Location = New System.Drawing.Point(77, 243)
        Me.lblC1Alt2.Name = "lblC1Alt2"
        Me.lblC1Alt2.Size = New System.Drawing.Size(93, 21)
        Me.lblC1Alt2.TabIndex = 104
        Me.lblC1Alt2.Tag = ""
        Me.lblC1Alt2.Text = "Alternative2"
        Me.lblC1Alt2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblC1Alt1
        '
        Me.lblC1Alt1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblC1Alt1.Location = New System.Drawing.Point(77, 218)
        Me.lblC1Alt1.Name = "lblC1Alt1"
        Me.lblC1Alt1.Size = New System.Drawing.Size(93, 21)
        Me.lblC1Alt1.TabIndex = 103
        Me.lblC1Alt1.Tag = ""
        Me.lblC1Alt1.Text = "Alternative1"
        Me.lblC1Alt1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblC1Primary
        '
        Me.lblC1Primary.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblC1Primary.Location = New System.Drawing.Point(77, 193)
        Me.lblC1Primary.Name = "lblC1Primary"
        Me.lblC1Primary.Size = New System.Drawing.Size(93, 21)
        Me.lblC1Primary.TabIndex = 102
        Me.lblC1Primary.Tag = ""
        Me.lblC1Primary.Text = "Primary"
        Me.lblC1Primary.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label6
        '
        Me.Label6.Font = New System.Drawing.Font("Consolas", 9.75!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Label6.Location = New System.Drawing.Point(9, 293)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(65, 21)
        Me.Label6.TabIndex = 95
        Me.Label6.Text = "Alt4"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label7
        '
        Me.Label7.Font = New System.Drawing.Font("Consolas", 9.75!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Label7.Location = New System.Drawing.Point(9, 267)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(65, 21)
        Me.Label7.TabIndex = 94
        Me.Label7.Text = "Alt3"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label8
        '
        Me.Label8.Font = New System.Drawing.Font("Consolas", 9.75!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Label8.Location = New System.Drawing.Point(9, 242)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(65, 21)
        Me.Label8.TabIndex = 93
        Me.Label8.Text = "Alt2"
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label9
        '
        Me.Label9.Font = New System.Drawing.Font("Consolas", 9.75!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Label9.Location = New System.Drawing.Point(9, 217)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(65, 21)
        Me.Label9.TabIndex = 92
        Me.Label9.Text = "Alt1"
        Me.Label9.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label10
        '
        Me.Label10.Font = New System.Drawing.Font("Consolas", 9.75!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Label10.Location = New System.Drawing.Point(-1, 192)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(75, 21)
        Me.Label10.TabIndex = 91
        Me.Label10.Text = "Primary"
        Me.Label10.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label50
        '
        Me.Label50.Font = New System.Drawing.Font("Consolas", 9.75!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label50.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Label50.Location = New System.Drawing.Point(9, 138)
        Me.Label50.Name = "Label50"
        Me.Label50.Size = New System.Drawing.Size(65, 21)
        Me.Label50.TabIndex = 84
        Me.Label50.Text = "Alt4"
        Me.Label50.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label48
        '
        Me.Label48.Font = New System.Drawing.Font("Consolas", 9.75!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label48.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Label48.Location = New System.Drawing.Point(9, 112)
        Me.Label48.Name = "Label48"
        Me.Label48.Size = New System.Drawing.Size(65, 21)
        Me.Label48.TabIndex = 83
        Me.Label48.Text = "Alt3"
        Me.Label48.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label47
        '
        Me.Label47.Font = New System.Drawing.Font("Consolas", 9.75!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label47.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Label47.Location = New System.Drawing.Point(9, 87)
        Me.Label47.Name = "Label47"
        Me.Label47.Size = New System.Drawing.Size(65, 21)
        Me.Label47.TabIndex = 82
        Me.Label47.Text = "Alt2"
        Me.Label47.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label46
        '
        Me.Label46.Font = New System.Drawing.Font("Consolas", 9.75!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label46.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Label46.Location = New System.Drawing.Point(9, 62)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(65, 21)
        Me.Label46.TabIndex = 81
        Me.Label46.Text = "Alt1"
        Me.Label46.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label37
        '
        Me.Label37.Font = New System.Drawing.Font("Consolas", 9.75!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label37.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Label37.Location = New System.Drawing.Point(-1, 37)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(75, 21)
        Me.Label37.TabIndex = 80
        Me.Label37.Text = "Primary"
        Me.Label37.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label36
        '
        Me.Label36.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label36.Location = New System.Drawing.Point(578, 294)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(105, 21)
        Me.Label36.TabIndex = 77
        Me.Label36.Tag = "MiscAlternative4"
        Me.Label36.Text = "Alternative4"
        Me.Label36.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label38
        '
        Me.Label38.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label38.Location = New System.Drawing.Point(578, 268)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(105, 21)
        Me.Label38.TabIndex = 75
        Me.Label38.Tag = "MiscAlternative3"
        Me.Label38.Text = "Alternative3"
        Me.Label38.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label40
        '
        Me.Label40.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label40.Location = New System.Drawing.Point(578, 243)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(105, 21)
        Me.Label40.TabIndex = 73
        Me.Label40.Tag = "MiscAlternative2"
        Me.Label40.Text = "Alternative2"
        Me.Label40.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label42
        '
        Me.Label42.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label42.Location = New System.Drawing.Point(578, 218)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(105, 21)
        Me.Label42.TabIndex = 71
        Me.Label42.Tag = "MiscAlternative1"
        Me.Label42.Text = "Alternative1"
        Me.Label42.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label44
        '
        Me.Label44.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label44.Location = New System.Drawing.Point(578, 193)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(105, 21)
        Me.Label44.TabIndex = 69
        Me.Label44.Tag = "MiscPrimary"
        Me.Label44.Text = "Primary"
        Me.Label44.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label49
        '
        Me.Label49.Font = New System.Drawing.Font("Consolas", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label49.Location = New System.Drawing.Point(579, 16)
        Me.Label49.Name = "Label49"
        Me.Label49.Size = New System.Drawing.Size(104, 21)
        Me.Label49.TabIndex = 65
        Me.Label49.Text = "Sails"
        Me.Label49.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblSolarSails
        '
        Me.lblSolarSails.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblSolarSails.Location = New System.Drawing.Point(578, 37)
        Me.lblSolarSails.Name = "lblSolarSails"
        Me.lblSolarSails.Size = New System.Drawing.Size(105, 21)
        Me.lblSolarSails.TabIndex = 50
        Me.lblSolarSails.Tag = "SailShip_SailsPrimary"
        Me.lblSolarSails.Text = "Solar Sails"
        Me.lblSolarSails.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label29
        '
        Me.Label29.Font = New System.Drawing.Font("Consolas", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label29.Location = New System.Drawing.Point(480, 16)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(93, 21)
        Me.Label29.TabIndex = 49
        Me.Label29.Text = "Rock"
        Me.Label29.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblRockAlt4
        '
        Me.lblRockAlt4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblRockAlt4.Location = New System.Drawing.Point(480, 138)
        Me.lblRockAlt4.Name = "lblRockAlt4"
        Me.lblRockAlt4.Size = New System.Drawing.Size(93, 21)
        Me.lblRockAlt4.TabIndex = 48
        Me.lblRockAlt4.Tag = "RockAlternative4"
        Me.lblRockAlt4.Text = "Alternative4"
        Me.lblRockAlt4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label23
        '
        Me.Label23.Font = New System.Drawing.Font("Consolas", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.Location = New System.Drawing.Point(381, 16)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(93, 21)
        Me.Label23.TabIndex = 49
        Me.Label23.Text = "Stone"
        Me.Label23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblRockAlt3
        '
        Me.lblRockAlt3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblRockAlt3.Location = New System.Drawing.Point(480, 112)
        Me.lblRockAlt3.Name = "lblRockAlt3"
        Me.lblRockAlt3.Size = New System.Drawing.Size(93, 21)
        Me.lblRockAlt3.TabIndex = 47
        Me.lblRockAlt3.Tag = "RockAlternative3"
        Me.lblRockAlt3.Text = "Alternative3"
        Me.lblRockAlt3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblStoneAlt4
        '
        Me.lblStoneAlt4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblStoneAlt4.Location = New System.Drawing.Point(381, 138)
        Me.lblStoneAlt4.Name = "lblStoneAlt4"
        Me.lblStoneAlt4.Size = New System.Drawing.Size(93, 21)
        Me.lblStoneAlt4.TabIndex = 48
        Me.lblStoneAlt4.Tag = "StoneAlternative4"
        Me.lblStoneAlt4.Text = "Alternative4"
        Me.lblStoneAlt4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblRockAlt2
        '
        Me.lblRockAlt2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblRockAlt2.Location = New System.Drawing.Point(480, 87)
        Me.lblRockAlt2.Name = "lblRockAlt2"
        Me.lblRockAlt2.Size = New System.Drawing.Size(93, 21)
        Me.lblRockAlt2.TabIndex = 46
        Me.lblRockAlt2.Tag = "RockAlternative2"
        Me.lblRockAlt2.Text = "Alternative2"
        Me.lblRockAlt2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblStoneAlt3
        '
        Me.lblStoneAlt3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblStoneAlt3.Location = New System.Drawing.Point(381, 112)
        Me.lblStoneAlt3.Name = "lblStoneAlt3"
        Me.lblStoneAlt3.Size = New System.Drawing.Size(93, 21)
        Me.lblStoneAlt3.TabIndex = 47
        Me.lblStoneAlt3.Tag = "StoneAlternative3"
        Me.lblStoneAlt3.Text = "Alternative3"
        Me.lblStoneAlt3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblRockAlt1
        '
        Me.lblRockAlt1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblRockAlt1.Location = New System.Drawing.Point(480, 62)
        Me.lblRockAlt1.Name = "lblRockAlt1"
        Me.lblRockAlt1.Size = New System.Drawing.Size(93, 21)
        Me.lblRockAlt1.TabIndex = 45
        Me.lblRockAlt1.Tag = "RockAlternative1"
        Me.lblRockAlt1.Text = "Alternative1"
        Me.lblRockAlt1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblStoneAlt2
        '
        Me.lblStoneAlt2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblStoneAlt2.Location = New System.Drawing.Point(381, 87)
        Me.lblStoneAlt2.Name = "lblStoneAlt2"
        Me.lblStoneAlt2.Size = New System.Drawing.Size(93, 21)
        Me.lblStoneAlt2.TabIndex = 46
        Me.lblStoneAlt2.Tag = "StoneAlternative2"
        Me.lblStoneAlt2.Text = "Alternative2"
        Me.lblStoneAlt2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblRockPrimary
        '
        Me.lblRockPrimary.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblRockPrimary.Location = New System.Drawing.Point(480, 37)
        Me.lblRockPrimary.Name = "lblRockPrimary"
        Me.lblRockPrimary.Size = New System.Drawing.Size(93, 21)
        Me.lblRockPrimary.TabIndex = 44
        Me.lblRockPrimary.Tag = "RockPrimary"
        Me.lblRockPrimary.Text = "Primary"
        Me.lblRockPrimary.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblStoneAlt1
        '
        Me.lblStoneAlt1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblStoneAlt1.Location = New System.Drawing.Point(381, 62)
        Me.lblStoneAlt1.Name = "lblStoneAlt1"
        Me.lblStoneAlt1.Size = New System.Drawing.Size(93, 21)
        Me.lblStoneAlt1.TabIndex = 45
        Me.lblStoneAlt1.Tag = "StoneAlternative1"
        Me.lblStoneAlt1.Text = "Alternative1"
        Me.lblStoneAlt1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblStonePrimary
        '
        Me.lblStonePrimary.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblStonePrimary.Location = New System.Drawing.Point(381, 37)
        Me.lblStonePrimary.Name = "lblStonePrimary"
        Me.lblStonePrimary.Size = New System.Drawing.Size(93, 21)
        Me.lblStonePrimary.TabIndex = 44
        Me.lblStonePrimary.Tag = "StonePrimary"
        Me.lblStonePrimary.Text = "Primary"
        Me.lblStonePrimary.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label22
        '
        Me.Label22.Font = New System.Drawing.Font("Consolas", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.Location = New System.Drawing.Point(280, 16)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(93, 21)
        Me.Label22.TabIndex = 43
        Me.Label22.Text = "Metal"
        Me.Label22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label21
        '
        Me.Label21.Font = New System.Drawing.Font("Consolas", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.Location = New System.Drawing.Point(180, 16)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(92, 21)
        Me.Label21.TabIndex = 42
        Me.Label21.Text = "Undercoat"
        Me.Label21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label20
        '
        Me.Label20.Font = New System.Drawing.Font("Consolas", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.Location = New System.Drawing.Point(77, 15)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(93, 21)
        Me.Label20.TabIndex = 41
        Me.Label20.Text = "Paint"
        Me.Label20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblMetalAlt4
        '
        Me.lblMetalAlt4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblMetalAlt4.Location = New System.Drawing.Point(280, 138)
        Me.lblMetalAlt4.Name = "lblMetalAlt4"
        Me.lblMetalAlt4.Size = New System.Drawing.Size(93, 21)
        Me.lblMetalAlt4.TabIndex = 40
        Me.lblMetalAlt4.Tag = "MetalAlternative4"
        Me.lblMetalAlt4.Text = "Alternative4"
        Me.lblMetalAlt4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblMetalAlt3
        '
        Me.lblMetalAlt3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblMetalAlt3.Location = New System.Drawing.Point(280, 112)
        Me.lblMetalAlt3.Name = "lblMetalAlt3"
        Me.lblMetalAlt3.Size = New System.Drawing.Size(93, 21)
        Me.lblMetalAlt3.TabIndex = 39
        Me.lblMetalAlt3.Tag = "MetalAlternative3"
        Me.lblMetalAlt3.Text = "Alternative3"
        Me.lblMetalAlt3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblMetalAlt2
        '
        Me.lblMetalAlt2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblMetalAlt2.Location = New System.Drawing.Point(280, 87)
        Me.lblMetalAlt2.Name = "lblMetalAlt2"
        Me.lblMetalAlt2.Size = New System.Drawing.Size(93, 21)
        Me.lblMetalAlt2.TabIndex = 38
        Me.lblMetalAlt2.Tag = "MetalAlternative2"
        Me.lblMetalAlt2.Text = "Alternative2"
        Me.lblMetalAlt2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblMetalAlt1
        '
        Me.lblMetalAlt1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblMetalAlt1.Location = New System.Drawing.Point(280, 62)
        Me.lblMetalAlt1.Name = "lblMetalAlt1"
        Me.lblMetalAlt1.Size = New System.Drawing.Size(93, 21)
        Me.lblMetalAlt1.TabIndex = 37
        Me.lblMetalAlt1.Tag = "MetalAlternative1"
        Me.lblMetalAlt1.Text = "Alternative1"
        Me.lblMetalAlt1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblMetalPrimary
        '
        Me.lblMetalPrimary.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblMetalPrimary.Location = New System.Drawing.Point(280, 37)
        Me.lblMetalPrimary.Name = "lblMetalPrimary"
        Me.lblMetalPrimary.Size = New System.Drawing.Size(93, 21)
        Me.lblMetalPrimary.TabIndex = 36
        Me.lblMetalPrimary.Tag = "MetalPrimary"
        Me.lblMetalPrimary.Text = "Primary"
        Me.lblMetalPrimary.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblPaintAlt4
        '
        Me.lblPaintAlt4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblPaintAlt4.Location = New System.Drawing.Point(77, 138)
        Me.lblPaintAlt4.Name = "lblPaintAlt4"
        Me.lblPaintAlt4.Size = New System.Drawing.Size(93, 21)
        Me.lblPaintAlt4.TabIndex = 35
        Me.lblPaintAlt4.Tag = "PaintAlternative4"
        Me.lblPaintAlt4.Text = "Alternative4"
        Me.lblPaintAlt4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblPaintAlt3
        '
        Me.lblPaintAlt3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblPaintAlt3.Location = New System.Drawing.Point(77, 112)
        Me.lblPaintAlt3.Name = "lblPaintAlt3"
        Me.lblPaintAlt3.Size = New System.Drawing.Size(93, 21)
        Me.lblPaintAlt3.TabIndex = 34
        Me.lblPaintAlt3.Tag = "PaintAlternative3"
        Me.lblPaintAlt3.Text = "Alternative3"
        Me.lblPaintAlt3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblPaintAlt2
        '
        Me.lblPaintAlt2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblPaintAlt2.Location = New System.Drawing.Point(77, 87)
        Me.lblPaintAlt2.Name = "lblPaintAlt2"
        Me.lblPaintAlt2.Size = New System.Drawing.Size(93, 21)
        Me.lblPaintAlt2.TabIndex = 33
        Me.lblPaintAlt2.Tag = "PaintAlternative2"
        Me.lblPaintAlt2.Text = "Alternative2"
        Me.lblPaintAlt2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblPaintAlt1
        '
        Me.lblPaintAlt1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblPaintAlt1.Location = New System.Drawing.Point(77, 62)
        Me.lblPaintAlt1.Name = "lblPaintAlt1"
        Me.lblPaintAlt1.Size = New System.Drawing.Size(93, 21)
        Me.lblPaintAlt1.TabIndex = 32
        Me.lblPaintAlt1.Tag = "PaintAlternative1"
        Me.lblPaintAlt1.Text = "Alternative1"
        Me.lblPaintAlt1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblUndercoatAlt4
        '
        Me.lblUndercoatAlt4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblUndercoatAlt4.Location = New System.Drawing.Point(179, 138)
        Me.lblUndercoatAlt4.Name = "lblUndercoatAlt4"
        Me.lblUndercoatAlt4.Size = New System.Drawing.Size(93, 21)
        Me.lblUndercoatAlt4.TabIndex = 31
        Me.lblUndercoatAlt4.Tag = "UndercoatAlternative4"
        Me.lblUndercoatAlt4.Text = "Alternative4"
        Me.lblUndercoatAlt4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblUndercoatAlt3
        '
        Me.lblUndercoatAlt3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblUndercoatAlt3.Location = New System.Drawing.Point(179, 112)
        Me.lblUndercoatAlt3.Name = "lblUndercoatAlt3"
        Me.lblUndercoatAlt3.Size = New System.Drawing.Size(93, 21)
        Me.lblUndercoatAlt3.TabIndex = 30
        Me.lblUndercoatAlt3.Tag = "UndercoatAlternative3"
        Me.lblUndercoatAlt3.Text = "Alternative3"
        Me.lblUndercoatAlt3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblUndercoatAlt2
        '
        Me.lblUndercoatAlt2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblUndercoatAlt2.Location = New System.Drawing.Point(179, 87)
        Me.lblUndercoatAlt2.Name = "lblUndercoatAlt2"
        Me.lblUndercoatAlt2.Size = New System.Drawing.Size(93, 21)
        Me.lblUndercoatAlt2.TabIndex = 29
        Me.lblUndercoatAlt2.Tag = "UndercoatAlternative2"
        Me.lblUndercoatAlt2.Text = "Alternative2"
        Me.lblUndercoatAlt2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblUndercoatAlt1
        '
        Me.lblUndercoatAlt1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblUndercoatAlt1.Location = New System.Drawing.Point(179, 62)
        Me.lblUndercoatAlt1.Name = "lblUndercoatAlt1"
        Me.lblUndercoatAlt1.Size = New System.Drawing.Size(93, 21)
        Me.lblUndercoatAlt1.TabIndex = 28
        Me.lblUndercoatAlt1.Tag = "UndercoatAlternative1"
        Me.lblUndercoatAlt1.Text = "Alternative1"
        Me.lblUndercoatAlt1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblUndercoatPrimary
        '
        Me.lblUndercoatPrimary.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblUndercoatPrimary.Location = New System.Drawing.Point(179, 37)
        Me.lblUndercoatPrimary.Name = "lblUndercoatPrimary"
        Me.lblUndercoatPrimary.Size = New System.Drawing.Size(93, 21)
        Me.lblUndercoatPrimary.TabIndex = 24
        Me.lblUndercoatPrimary.Tag = "UndercoatPrimary"
        Me.lblUndercoatPrimary.Text = "Primary"
        Me.lblUndercoatPrimary.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblPaintPrimary
        '
        Me.lblPaintPrimary.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblPaintPrimary.Location = New System.Drawing.Point(77, 37)
        Me.lblPaintPrimary.Name = "lblPaintPrimary"
        Me.lblPaintPrimary.Size = New System.Drawing.Size(93, 21)
        Me.lblPaintPrimary.TabIndex = 16
        Me.lblPaintPrimary.Tag = "PaintPrimary"
        Me.lblPaintPrimary.Text = "Primary"
        Me.lblPaintPrimary.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.cmdPaintAlternative1)
        Me.GroupBox3.Controls.Add(Me.cmdPaintAlternative2)
        Me.GroupBox3.Controls.Add(Me.cmdUndercoatPrimary)
        Me.GroupBox3.Controls.Add(Me.cmdPaintAlt3)
        Me.GroupBox3.Controls.Add(Me.cmdPaintPrimary)
        Me.GroupBox3.Location = New System.Drawing.Point(388, 19)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(142, 198)
        Me.GroupBox3.TabIndex = 16
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Map General Colors"
        '
        'cmdPaintAlternative1
        '
        Me.cmdPaintAlternative1.Location = New System.Drawing.Point(6, 119)
        Me.cmdPaintAlternative1.Name = "cmdPaintAlternative1"
        Me.cmdPaintAlternative1.Size = New System.Drawing.Size(130, 23)
        Me.cmdPaintAlternative1.TabIndex = 14
        Me.cmdPaintAlternative1.Text = "Decal 2"
        Me.cmdPaintAlternative1.UseVisualStyleBackColor = True
        '
        'cmdPaintAlternative2
        '
        Me.cmdPaintAlternative2.Location = New System.Drawing.Point(6, 94)
        Me.cmdPaintAlternative2.Name = "cmdPaintAlternative2"
        Me.cmdPaintAlternative2.Size = New System.Drawing.Size(130, 23)
        Me.cmdPaintAlternative2.TabIndex = 13
        Me.cmdPaintAlternative2.Text = "Decal 1"
        Me.cmdPaintAlternative2.UseVisualStyleBackColor = True
        '
        'cmdUndercoatPrimary
        '
        Me.cmdUndercoatPrimary.Location = New System.Drawing.Point(6, 69)
        Me.cmdUndercoatPrimary.Name = "cmdUndercoatPrimary"
        Me.cmdUndercoatPrimary.Size = New System.Drawing.Size(130, 23)
        Me.cmdUndercoatPrimary.TabIndex = 12
        Me.cmdUndercoatPrimary.Text = "Undercoat"
        Me.cmdUndercoatPrimary.UseVisualStyleBackColor = True
        '
        'cmdPaintAlt3
        '
        Me.cmdPaintAlt3.Location = New System.Drawing.Point(6, 44)
        Me.cmdPaintAlt3.Name = "cmdPaintAlt3"
        Me.cmdPaintAlt3.Size = New System.Drawing.Size(130, 23)
        Me.cmdPaintAlt3.TabIndex = 11
        Me.cmdPaintAlt3.Text = "Secondary Color"
        Me.cmdPaintAlt3.UseVisualStyleBackColor = True
        '
        'cmdPaintPrimary
        '
        Me.cmdPaintPrimary.Location = New System.Drawing.Point(6, 19)
        Me.cmdPaintPrimary.Name = "cmdPaintPrimary"
        Me.cmdPaintPrimary.Size = New System.Drawing.Size(130, 23)
        Me.cmdPaintPrimary.TabIndex = 10
        Me.cmdPaintPrimary.Text = "Primary Color"
        Me.cmdPaintPrimary.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.pbActive)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.txtActiveARGB)
        Me.GroupBox1.Controls.Add(Me.blkPrime)
        Me.GroupBox1.Controls.Add(Me.cmdASelect)
        Me.GroupBox1.Controls.Add(Me.cmdAPrev)
        Me.GroupBox1.Controls.Add(Me.txtAA)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.txtAB)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.txtAG)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.txtAR)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Location = New System.Drawing.Point(6, 19)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(376, 198)
        Me.GroupBox1.TabIndex = 3
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Active Color"
        '
        'pbActive
        '
        Me.pbActive.BackColor = System.Drawing.Color.Transparent
        Me.pbActive.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pbActive.Location = New System.Drawing.Point(159, 19)
        Me.pbActive.Name = "pbActive"
        Me.pbActive.Size = New System.Drawing.Size(211, 172)
        Me.pbActive.TabIndex = 16
        Me.pbActive.TabStop = False
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(7, 174)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(61, 13)
        Me.Label5.TabIndex = 14
        Me.Label5.Text = "ARGB Code"
        '
        'txtActiveARGB
        '
        Me.txtActiveARGB.Location = New System.Drawing.Point(73, 171)
        Me.txtActiveARGB.Name = "txtActiveARGB"
        Me.txtActiveARGB.Size = New System.Drawing.Size(80, 20)
        Me.txtActiveARGB.TabIndex = 13
        Me.txtActiveARGB.Text = "-1"
        Me.txtActiveARGB.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'cmdASelect
        '
        Me.cmdASelect.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdASelect.Location = New System.Drawing.Point(6, 112)
        Me.cmdASelect.Name = "cmdASelect"
        Me.cmdASelect.Size = New System.Drawing.Size(69, 23)
        Me.cmdASelect.TabIndex = 9
        Me.cmdASelect.Text = "Select"
        Me.cmdASelect.UseVisualStyleBackColor = True
        '
        'cmdAPrev
        '
        Me.cmdAPrev.Location = New System.Drawing.Point(84, 112)
        Me.cmdAPrev.Name = "cmdAPrev"
        Me.cmdAPrev.Size = New System.Drawing.Size(69, 23)
        Me.cmdAPrev.TabIndex = 8
        Me.cmdAPrev.Text = "Preview"
        Me.cmdAPrev.UseVisualStyleBackColor = True
        '
        'txtAA
        '
        Me.txtAA.Location = New System.Drawing.Point(26, 86)
        Me.txtAA.Name = "txtAA"
        Me.txtAA.Size = New System.Drawing.Size(127, 20)
        Me.txtAA.TabIndex = 7
        Me.txtAA.Text = "1.0"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(7, 89)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(13, 13)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "A"
        '
        'txtAB
        '
        Me.txtAB.Location = New System.Drawing.Point(26, 64)
        Me.txtAB.Name = "txtAB"
        Me.txtAB.Size = New System.Drawing.Size(127, 20)
        Me.txtAB.TabIndex = 5
        Me.txtAB.Text = "0.1"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(7, 67)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(13, 13)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "B"
        '
        'txtAG
        '
        Me.txtAG.Location = New System.Drawing.Point(26, 42)
        Me.txtAG.Name = "txtAG"
        Me.txtAG.Size = New System.Drawing.Size(127, 20)
        Me.txtAG.TabIndex = 3
        Me.txtAG.Text = "0.1"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(7, 45)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(13, 13)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "G"
        '
        'txtAR
        '
        Me.txtAR.Location = New System.Drawing.Point(26, 20)
        Me.txtAR.Name = "txtAR"
        Me.txtAR.Size = New System.Drawing.Size(127, 20)
        Me.txtAR.TabIndex = 1
        Me.txtAR.Text = "0.1"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(7, 23)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(13, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "R"
        '
        'StatusStrip1
        '
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.frmStatus})
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 597)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(1174, 22)
        Me.StatusStrip1.TabIndex = 4
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'frmStatus
        '
        Me.frmStatus.Name = "frmStatus"
        Me.frmStatus.Size = New System.Drawing.Size(158, 17)
        Me.frmStatus.Text = "NMS JSON Colour Generator"
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'frmShipColor
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1174, 619)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.txtOutput)
        Me.Font = New System.Drawing.Font("Consolas", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frmShipColor"
        Me.Text = "NMS JSON Colour Generator"
        CType(Me.blkPrime, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        Me.gbColorMap.ResumeLayout(False)
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.pbActive, System.ComponentModel.ISupportInitialize).EndInit()
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents txtOutput As TextBox
    Friend WithEvents ColorDialog1 As ColorDialog
    Friend WithEvents ToolTip1 As ToolTip
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents blkPrime As PictureBox
    Friend WithEvents cmdAPrev As Button
    Friend WithEvents txtAA As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents txtAB As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents txtAG As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents txtAR As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents cmdASelect As Button
    Friend WithEvents Label5 As Label
    Friend WithEvents txtActiveARGB As TextBox
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents cmdPaintAlternative1 As Button
    Friend WithEvents cmdPaintAlternative2 As Button
    Friend WithEvents cmdUndercoatPrimary As Button
    Friend WithEvents cmdPaintAlt3 As Button
    Friend WithEvents cmdPaintPrimary As Button
    Friend WithEvents gbColorMap As GroupBox
    Friend WithEvents lblPaintPrimary As Label
    Friend WithEvents cmdGenerate As Button
    Friend WithEvents Label35 As Label
    Friend WithEvents Label36 As Label
    Friend WithEvents Label38 As Label
    Friend WithEvents Label40 As Label
    Friend WithEvents Label42 As Label
    Friend WithEvents Label44 As Label
    Friend WithEvents Label49 As Label
    Friend WithEvents lblSolarSails As Label
    Friend WithEvents Label29 As Label
    Friend WithEvents lblRockAlt4 As Label
    Friend WithEvents Label23 As Label
    Friend WithEvents lblRockAlt3 As Label
    Friend WithEvents lblStoneAlt4 As Label
    Friend WithEvents lblRockAlt2 As Label
    Friend WithEvents lblStoneAlt3 As Label
    Friend WithEvents lblRockAlt1 As Label
    Friend WithEvents lblStoneAlt2 As Label
    Friend WithEvents lblRockPrimary As Label
    Friend WithEvents lblStoneAlt1 As Label
    Friend WithEvents lblStonePrimary As Label
    Friend WithEvents Label22 As Label
    Friend WithEvents Label21 As Label
    Friend WithEvents Label20 As Label
    Friend WithEvents lblMetalAlt4 As Label
    Friend WithEvents lblMetalAlt3 As Label
    Friend WithEvents lblMetalAlt2 As Label
    Friend WithEvents lblMetalAlt1 As Label
    Friend WithEvents lblMetalPrimary As Label
    Friend WithEvents lblPaintAlt4 As Label
    Friend WithEvents lblPaintAlt3 As Label
    Friend WithEvents lblPaintAlt2 As Label
    Friend WithEvents lblPaintAlt1 As Label
    Friend WithEvents lblUndercoatAlt4 As Label
    Friend WithEvents lblUndercoatAlt3 As Label
    Friend WithEvents lblUndercoatAlt2 As Label
    Friend WithEvents lblUndercoatAlt1 As Label
    Friend WithEvents lblUndercoatPrimary As Label
    Friend WithEvents GroupBox5 As GroupBox
    Friend WithEvents cmdMonoGen As Button
    Friend WithEvents txtMonoA As TextBox
    Friend WithEvents Label39 As Label
    Friend WithEvents txtMonoB As TextBox
    Friend WithEvents Label41 As Label
    Friend WithEvents txtMonoG As TextBox
    Friend WithEvents Label43 As Label
    Friend WithEvents txtMonoR As TextBox
    Friend WithEvents Label45 As Label
    Friend WithEvents cmdOutfitJSON As Button
    Friend WithEvents Label50 As Label
    Friend WithEvents Label48 As Label
    Friend WithEvents Label47 As Label
    Friend WithEvents Label46 As Label
    Friend WithEvents Label37 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents StatusStrip1 As StatusStrip
    Friend WithEvents frmStatus As ToolStripStatusLabel
    Friend WithEvents lblC3Alt4 As Label
    Friend WithEvents lblC3Alt3 As Label
    Friend WithEvents lblC3Alt2 As Label
    Friend WithEvents lblC3Alt1 As Label
    Friend WithEvents lblC3Primary As Label
    Friend WithEvents lblC2Alt4 As Label
    Friend WithEvents lblC2Alt3 As Label
    Friend WithEvents lblC2Alt2 As Label
    Friend WithEvents lblC2Alt1 As Label
    Friend WithEvents lblC2Primary As Label
    Friend WithEvents cbCust03 As ComboBox
    Friend WithEvents cbCust02 As ComboBox
    Friend WithEvents cbCust01 As ComboBox
    Friend WithEvents lblC1Alt4 As Label
    Friend WithEvents lblC1Alt3 As Label
    Friend WithEvents lblC1Alt2 As Label
    Friend WithEvents lblC1Alt1 As Label
    Friend WithEvents lblC1Primary As Label
    Friend WithEvents cbCust05 As ComboBox
    Friend WithEvents cbCust04 As ComboBox
    Friend WithEvents lblC5Alt4 As Label
    Friend WithEvents lblC5Alt3 As Label
    Friend WithEvents lblC5Alt2 As Label
    Friend WithEvents lblC5Alt1 As Label
    Friend WithEvents lblC5Primary As Label
    Friend WithEvents lblC4Alt4 As Label
    Friend WithEvents lblC4Alt3 As Label
    Friend WithEvents lblC4Alt2 As Label
    Friend WithEvents lblC4Alt1 As Label
    Friend WithEvents lblC4Primary As Label
    Friend WithEvents cmdLoadColorMap As Button
    Friend WithEvents cmdSaveColorMap As Button
    Friend WithEvents OpenFileDialog1 As OpenFileDialog
    Friend WithEvents SaveFileDialog1 As SaveFileDialog
    Friend WithEvents pbActive As PictureBox
End Class

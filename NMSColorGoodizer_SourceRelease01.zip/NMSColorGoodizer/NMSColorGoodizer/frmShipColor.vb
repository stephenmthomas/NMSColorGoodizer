﻿Public Class frmShipColor
    Public StrPalettes As String = "Grass,Plant,Leaf,Wood,Rock,Stone,Crystal,Sand,Dirt,Metal,Paint,Plastic,Fur,Scale,Feather,Water,Cloud,Sky,Space,Underbelly,Undercoat,Snow,SkyHorizon,SkyFog,SkyHeightFog,SkySunset,SkyNight,WaterNear,SpaceCloud,SpaceBottom,SpaceSolar,SpaceLight,Warrior,Scientific,Trader,WarriorAlt,ScientificAlt,TraderAlt,RockSaturated,RockLight,RockDark,PlanetRing,Custom_Head,Custom_Torso,Custom_Chest_Armour,Custom_Backpack,Custom_Arms,Custom_Hands,Custom_Legs,Custom_Feet,Cave,GrassAlt,BioShip_Body,BioShip_Underbelly,BioShip_Cockpit,SailShip_Sails"
    Public StrColourAlts As String = "Primary,Alternative1,Alternative2,Alternative3,Alternative4" 'Unique,MatchGround,None"
    Public OutfitPalettes As String = "Custom_Head,Custom_Torso,Custom_Chest_Armor,Custom_Backpack,Custom_Hands,Custom_Legs,Custom_Feet"
    Public OutfitColours As String = "Primary,Alternative1,Alternative2"
    Public ColorSwatch As String
    Public ActiveColour As String
    Public sPalettes As String()
    Public sColours As String()
    Public sPaintCodes As String
    Public CurrentR, CurrentG, CurrentB, CurrentA As String
    Public ColourDict As New SortedList(Of String, String)
    'Need another array that stores Palette+Colour,RGBAData
    'i.e. if Pal="Metal" and Col="Primary", find "MetalPrimary" value in array... MetalPrimary,RGBA

    'Body 1st       Paint           Primary
    'Body 2nd       Paint           Alternative3
    'Decal 1st      Paint           Alternative2
    'Decal 2nd      Paint           Alternative1
    'Undercoat      Undercoat       Primary
    Sub SetTagColor(WhatTag As String, WhatColor As String)
        Dim setColor As Color


        If WhatColor = "-X" Then
            setColor = Color.Black
        Else
            setColor = Color.FromArgb(WhatColor)
        End If

        For Each cControl In gbColorMap.Controls
            If (cControl.GetType() Is GetType(Label)) Then
                If cControl.BorderStyle = BorderStyle.FixedSingle Then
                    If cControl.Tag.ToString = WhatTag Then
                        cControl.BackColor = setColor
                        cControl.Text = WhatColor
                    End If
                End If
            End If

        Next
    End Sub
    Private Sub frmMain_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim cPal, cCol As String

        ColorSwatch = My.Computer.FileSystem.ReadAllText("str_swatch_format.dat")
        'ColorSwatch = My.Computer.FileSystem.ReadAllText("str_swatch.dat")

        sPalettes = StrPalettes.Split(New Char() {","c})
        sColours = StrColourAlts.Split(New Char() {","c})

        For Each cPal In sPalettes
            For Each cCol In sColours
                sPaintCodes = sPaintCodes & cPal & cCol & ":0,"
                ColourDict.Add(cPal & cCol, "-1")

            Next
        Next


        OpenFileDialog1.InitialDirectory = Application.StartupPath
        OpenFileDialog1.FileName = ""
        OpenFileDialog1.Filter = "NCG files (*.ncg)|*.ncg|All files (*.*)|*.*"

        SaveFileDialog1.InitialDirectory = Application.StartupPath
        SaveFileDialog1.FileName = ""
        SaveFileDialog1.Filter = "NCG files (*.ncg)|*.ncg|All files (*.*)|*.*"

        PopulateMouseHandles()
        PopulateCustomBoxes()


    End Sub
    Sub PopulateCustomBoxes()
        Dim cPal As String

        For Each cPal In sPalettes
            cbCust01.Items.Add(cPal)
            cbCust02.Items.Add(cPal)
            cbCust03.Items.Add(cPal)
            cbCust04.Items.Add(cPal)
            cbCust05.Items.Add(cPal)
        Next
    End Sub
    Public Function ConvRGBA2Col(vR As Integer, vG As Integer, vB As Integer, vA As Integer) As Color
        ConvRGBA2Col = Color.FromArgb(vA * 255, vR * 255, vG * 255, vB * 255)

    End Function
    Sub NewActiveColor(WhatColor As String)
        Dim newActive As Color
        newActive = Color.FromArgb(WhatColor)

        ActiveColour = Str(newActive.ToArgb())
        txtActiveARGB.Text = ActiveColour
        pbActive.BackColor = newActive

        CurrentR = (newActive.R / 255).ToString("n5")
        CurrentG = (newActive.G / 255).ToString("n5")
        CurrentB = (newActive.B / 255).ToString("n5")
        CurrentA = (newActive.A / 255).ToString("n5")

        txtAR.Text = CurrentR
        txtAG.Text = CurrentG
        txtAB.Text = CurrentB
        txtAA.Text = CurrentA

    End Sub
    Private Sub cmdAPrev_Click(sender As Object, e As EventArgs) Handles cmdAPrev.Click
        On Error GoTo PrevErr
        Dim myColor As Color

        myColor = Color.FromArgb(Val(txtAA.Text) * 255, Val(txtAR.Text) * 255, Val(txtAG.Text) * 255, Val(txtAB.Text) * 255)
        pbActive.BackColor = myColor
        NewActiveColor(Str(myColor.ToArgb()))

        Exit Sub

PrevErr:
        If Val(txtAR.Text) < 0 Then
            pbActive.BackColor = Color.Black
            txtActiveARGB.Text = "-X"
        Else
            MsgBox("There was an error previewing this color.")
        End If
    End Sub


    Private Sub blkPrime_Click(sender As Object, e As EventArgs) Handles blkPrime.Click
        txtAR.Text = "-1.0"
        txtAG.Text = "-1.0"
        txtAB.Text = "-1.0"
        txtAA.Text = "1.0"
        pbActive.BackColor = Color.Black
        txtActiveARGB.Text = "-X"
    End Sub

    Private Sub txtPrimeA_TextChanged(sender As Object, e As EventArgs) Handles txtAA.TextChanged

    End Sub

    Private Sub cmdASelect_Click(sender As Object, e As EventArgs) Handles cmdASelect.Click

        If ColorDialog1.ShowDialog <> Windows.Forms.DialogResult.Cancel Then
            NewActiveColor(Str(ColorDialog1.Color.ToArgb()))
        End If
    End Sub



    Private Sub cmdMonoGen_Click(sender As Object, e As EventArgs) Handles cmdMonoGen.Click
        Dim cPal As String
        Dim cCol As String
        Dim NewSwatch As String
        Dim strOutput As String

        sPalettes = StrPalettes.Split(New Char() {","c})
        sColours = StrColourAlts.Split(New Char() {","c})

        strOutput = "[" & vbCrLf


        For Each cPal In sPalettes
            For Each cCol In sColours
                NewSwatch = Replace(ColorSwatch, "ZbX_STRPAL", cPal)
                NewSwatch = Replace(NewSwatch, "ZbX_STRCOL", cCol)
                NewSwatch = Replace(NewSwatch, "ZbX_R", txtMonoR.Text)
                NewSwatch = Replace(NewSwatch, "ZbX_G", txtMonoG.Text)
                NewSwatch = Replace(NewSwatch, "ZbX_B", txtMonoB.Text)
                NewSwatch = Replace(NewSwatch, "ZbX_A", txtMonoA.Text)
                strOutput = strOutput & NewSwatch & vbCrLf
                'need a function called Swatch that takes cPal, cCol, and Int32 color as argument and generates a new line
            Next
        Next

        strOutput = strOutput & "]"
        strOutput = Replace(strOutput, "}," & vbCrLf & "]", "}" & vbCrLf & "]")

        txtOutput.Text = strOutput
    End Sub

    Private Sub cmdOutfitJSON_Click(sender As Object, e As EventArgs) Handles cmdOutfitJSON.Click
        Dim cPal As String
        Dim cCol As String
        Dim NewSwatch As String
        Dim strOutput As String

        sPalettes = OutfitPalettes.Split(New Char() {","c})
        sColours = OutfitColours.Split(New Char() {","c})

        strOutput = "[" & vbCrLf


        For Each cPal In sPalettes
            For Each cCol In sColours
                NewSwatch = Replace(ColorSwatch, "ZbX_STRPAL", cPal)
                NewSwatch = Replace(NewSwatch, "ZbX_STRCOL", cCol)
                NewSwatch = Replace(NewSwatch, "ZbX_R", txtMonoR.Text)
                NewSwatch = Replace(NewSwatch, "ZbX_G", txtMonoG.Text)
                NewSwatch = Replace(NewSwatch, "ZbX_B", txtMonoB.Text)
                NewSwatch = Replace(NewSwatch, "ZbX_A", txtMonoA.Text)
                strOutput = strOutput & NewSwatch & vbCrLf
                'need a function called Swatch that takes cPal, cCol, and Int32 color as argument and generates a new line
            Next
        Next

        strOutput = strOutput & "]"
        strOutput = Replace(strOutput, "}," & vbCrLf & "]", "}" & vbCrLf & "]")

        txtOutput.Text = strOutput



    End Sub
    Private Sub cmdGenerate_Click(sender As Object, e As EventArgs) Handles cmdGenerate.Click
        Dim cPal As String
        Dim cCol As String
        Dim NewSwatch As String
        Dim iColor As Color
        Dim strOutput As String
        Dim TagColor As String

        sPalettes = StrPalettes.Split(New Char() {","c})
        sColours = StrColourAlts.Split(New Char() {","c})

        strOutput = "[" & vbCrLf

        TagColor = ""

        For Each cPal In sPalettes 'Cycle through Paint Types [Metal, Rock, etc.]
            For Each cCol In sColours 'Cycle through primary to alternative 4

                TagColor = FromColorMap(cPal & cCol) 'Gets the color value of the matching Palette+Color label
                Debug.Print(cPal & "," & cCol & "," & TagColor & ":")


                If IsNumeric(TagColor) Then 'If this isn't a number, then its "Primary", "Alternative1", etc.
                    iColor = Color.FromArgb(TagColor)
                    CurrentR = (iColor.R / 255).ToString("n5")
                    CurrentG = (iColor.G / 255).ToString("n5")
                    CurrentB = (iColor.B / 255).ToString("n5")
                    CurrentA = (iColor.A / 255).ToString("n5")
                End If

                If TagColor = "" Then
                    TagColor = FromColorMap("Misc" & cCol)


                    If IsNumeric(TagColor) Then 'Set Fill color if chosen
                        iColor = Color.FromArgb(FromColorMap("Misc" & cCol))
                    Else
                        iColor = Color.FromArgb(-1) 'Otherwise set white as default color
                    End If

                    CurrentR = (iColor.R / 255).ToString("n5")
                    CurrentG = (iColor.G / 255).ToString("n5")
                    CurrentB = (iColor.B / 255).ToString("n5")
                    CurrentA = (iColor.A / 255).ToString("n5")

                End If

                If TagColor = "-X" Then
                    CurrentR = "-1.0"
                    CurrentG = "-1.0"
                    CurrentB = "-1.0"
                    CurrentA = "1.0"
                End If

                'Replace the palette+Colour string with the appropriate values
                NewSwatch = Replace(ColorSwatch, "ZbX_STRPAL", cPal)
                NewSwatch = Replace(NewSwatch, "ZbX_STRCOL", cCol)
                NewSwatch = Replace(NewSwatch, "ZbX_R", CurrentR)
                NewSwatch = Replace(NewSwatch, "ZbX_G", CurrentG)
                NewSwatch = Replace(NewSwatch, "ZbX_B", CurrentB)
                NewSwatch = Replace(NewSwatch, "ZbX_A", CurrentA)
                strOutput = strOutput & NewSwatch & vbCrLf


            Next
        Next

        strOutput = strOutput & "]"
        strOutput = Replace(strOutput, "}," & vbCrLf & "]", "}" & vbCrLf & "]") 'Trim this to prevent JSON errors.

        txtOutput.Text = strOutput
    End Sub
    Private Sub GroupBox2_Enter(sender As Object, e As EventArgs) Handles GroupBox2.Enter

    End Sub
    Sub PopulateMouseHandles()
        For Each cControl In gbColorMap.Controls
            If (cControl.GetType() Is GetType(Label)) Then
                If cControl.BorderStyle = BorderStyle.FixedSingle Then
                    AddHandler DirectCast(cControl, Label).Click, AddressOf ColorMapShiftClick
                    AddHandler DirectCast(cControl, Label).DoubleClick, AddressOf ColorMapDblClick
                    AddHandler DirectCast(cControl, Label).MouseDown, AddressOf ColorMapRightClick
                End If
            End If

        Next
    End Sub
    Function FromColorMap(WhatTag As String) As String
        'Returns the color value / text of the label with the matching tag
        'FromColorMap = "-1"
        For Each cControl In gbColorMap.Controls
            If (cControl.GetType() Is GetType(Label)) Then
                If cControl.BorderStyle = BorderStyle.FixedSingle Then
                    If cControl.Tag.ToString = WhatTag Then
                        Debug.Print("Found active paint code.")
                        FromColorMap = cControl.Text
                    End If
                End If
            End If
        Next
    End Function


    Private Sub cbCust01_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cbCust01.SelectedIndexChanged
        lblC1Primary.Tag = cbCust01.Text & "Primary"
        lblC1Alt1.Tag = cbCust01.Text & "Alternative1"
        lblC1Alt2.Tag = cbCust01.Text & "Alternative2"
        lblC1Alt3.Tag = cbCust01.Text & "Alternative3"
        lblC1Alt4.Tag = cbCust01.Text & "Alternative4"
    End Sub

    Private Sub cbCust02_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cbCust02.SelectedIndexChanged
        lblC2Primary.Tag = cbCust02.Text & "Primary"
        lblC2Alt1.Tag = cbCust02.Text & "Alternative1"
        lblC2Alt2.Tag = cbCust02.Text & "Alternative2"
        lblC2Alt3.Tag = cbCust02.Text & "Alternative3"
        lblC2Alt4.Tag = cbCust02.Text & "Alternative4"
    End Sub

    Private Sub cbCust03_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cbCust03.SelectedIndexChanged
        lblC3Primary.Tag = cbCust03.Text & "Primary"
        lblC3Alt1.Tag = cbCust03.Text & "Alternative1"
        lblC3Alt2.Tag = cbCust03.Text & "Alternative2"
        lblC3Alt3.Tag = cbCust03.Text & "Alternative3"
        lblC3Alt4.Tag = cbCust03.Text & "Alternative4"
    End Sub

    Private Sub cmdPaintPrimary_Click(sender As Object, e As EventArgs) Handles cmdPaintPrimary.Click
        SetTagColor("PaintPrimary", txtActiveARGB.Text)

    End Sub

    Private Sub cmdPaintAlt3_Click(sender As Object, e As EventArgs) Handles cmdPaintAlt3.Click
        SetTagColor("PaintAlternative3", txtActiveARGB.Text)
    End Sub

    Private Sub cmdUndercoatPrimary_Click(sender As Object, e As EventArgs) Handles cmdUndercoatPrimary.Click
        SetTagColor("UndercoatPrimary", txtActiveARGB.Text)
    End Sub

    Private Sub cmdPaintAlternative2_Click(sender As Object, e As EventArgs) Handles cmdPaintAlternative2.Click
        SetTagColor("PaintAlternative2", txtActiveARGB.Text)
    End Sub

    Private Sub cmdPaintAlternative1_Click(sender As Object, e As EventArgs) Handles cmdPaintAlternative1.Click
        SetTagColor("PaintAlternative1", txtActiveARGB.Text)
    End Sub

    Private Sub cbCust04_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cbCust04.SelectedIndexChanged
        lblC4Primary.Tag = cbCust04.Text & "Primary"
        lblC4Alt1.Tag = cbCust04.Text & "Alternative1"
        lblC4Alt2.Tag = cbCust04.Text & "Alternative2"
        lblC4Alt3.Tag = cbCust04.Text & "Alternative3"
        lblC4Alt4.Tag = cbCust04.Text & "Alternative4"
    End Sub

    Private Sub cbCust05_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cbCust05.SelectedIndexChanged
        lblC5Primary.Tag = cbCust05.Text & "Primary"
        lblC5Alt1.Tag = cbCust05.Text & "Alternative1"
        lblC5Alt2.Tag = cbCust05.Text & "Alternative2"
        lblC5Alt3.Tag = cbCust05.Text & "Alternative3"
        lblC5Alt4.Tag = cbCust05.Text & "Alternative4"
    End Sub

    Private Sub cmdSaveColorMap_Click(sender As Object, e As EventArgs) Handles cmdSaveColorMap.Click
        Dim OutputData As String

        OutputData = ""

        If cbCust01.Text <> "" Then OutputData = OutputData & "Custom01," & cbCust01.Text & vbNewLine
        If cbCust02.Text <> "" Then OutputData = OutputData & "Custom02," & cbCust02.Text & vbNewLine
        If cbCust03.Text <> "" Then OutputData = OutputData & "Custom03," & cbCust03.Text & vbNewLine
        If cbCust04.Text <> "" Then OutputData = OutputData & "Custom04," & cbCust04.Text & vbNewLine
        If cbCust05.Text <> "" Then OutputData = OutputData & "Custom05," & cbCust05.Text & vbNewLine

        For Each cControl In gbColorMap.Controls
            If (cControl.GetType() Is GetType(Label)) Then
                If cControl.BorderStyle = BorderStyle.FixedSingle Then
                    If IsNumeric(cControl.text) Then
                        If cControl.tag <> "" Then OutputData = OutputData & cControl.Tag & "," & cControl.text & vbNewLine
                    ElseIf cControl.text = "-X" Then
                        If cControl.tag <> "" Then OutputData = OutputData & cControl.Tag & ",-X" & vbNewLine
                    End If
                End If
            End If
        Next

        If OutputData <> "" Then
            If SaveFileDialog1.ShowDialog() = DialogResult.OK Then
                System.IO.File.WriteAllText(SaveFileDialog1.FileName, OutputData)
            End If
        End If




    End Sub
    Sub RefreshForm()


    End Sub
    Private Sub cmdLoadColorMap_Click(sender As Object, e As EventArgs) Handles cmdLoadColorMap.Click
        Dim LineCSV() As String


        If OpenFileDialog1.ShowDialog() = DialogResult.OK Then

            For Each Line As String In IO.File.ReadLines(OpenFileDialog1.FileName)
                LineCSV = Split(Line, ",")

                If LineCSV(0) = "Custom01" Then cbCust01.Text = LineCSV(1)
                If LineCSV(0) = "Custom02" Then cbCust02.Text = LineCSV(1)
                If LineCSV(0) = "Custom03" Then cbCust03.Text = LineCSV(1)
                If LineCSV(0) = "Custom04" Then cbCust04.Text = LineCSV(1)
                If LineCSV(0) = "Custom05" Then cbCust05.Text = LineCSV(1)

                SetColorByTag(LineCSV(0), LineCSV(1))

            Next
        End If
    End Sub
    Sub SetColorByTag(WhatTag As String, WhatColor As String)
        For Each cControl In gbColorMap.Controls
            If (cControl.GetType() Is GetType(Label)) Then
                If cControl.BorderStyle = BorderStyle.FixedSingle Then
                    If cControl.Tag.ToString = WhatTag Then
                        cControl.Text = WhatColor
                        If WhatColor = "-X" Then
                            cControl.BackColor = Color.Black
                            cControl.ForeColor = Color.White
                        ElseIf IsNumeric(Val(WhatColor)) Then
                            cControl.BackColor = Color.FromArgb(WhatColor)
                            cControl.ForeColor = Color.Black
                        End If

                    End If
                End If
            End If

        Next
    End Sub
    Private Sub ColorMapShiftClick(ByVal Sender As Object, ByVal e As EventArgs)
        'Sets the Color Map label to the active color
        If My.Computer.Keyboard.ShiftKeyDown Then
            Sender.BackColor = Color.FromArgb(ActiveColour)
            Sender.ForeColor = Color.Black
            Sender.Text = ActiveColour
            If txtActiveARGB.Text = "-X" Then
                Sender.BackColor = Color.Black
                Sender.Text = "-X"
                Sender.ForeColor = Color.White
            End If
        End If
    End Sub
    Private Sub ColorMapDblClick(ByVal Sender As Object, ByVal e As EventArgs)
        'Opens the Color Dialog and sets the color
        If ColorDialog1.ShowDialog <> Windows.Forms.DialogResult.Cancel Then
            Sender.BackColor = ColorDialog1.Color
            Sender.ForeColor = Color.Black
            Sender.Text = Str(ColorDialog1.Color.ToArgb())
        End If
    End Sub
    Private Sub ColorMapRightClick(ByVal Sender As Object, ByVal e As MouseEventArgs)
        'Makes the selected color map color become the active color
        If e.Button = MouseButtons.Right Then
            If IsNumeric(Sender.text) Then
                NewActiveColor(Sender.Text)
            End If

        End If
    End Sub

End Class
